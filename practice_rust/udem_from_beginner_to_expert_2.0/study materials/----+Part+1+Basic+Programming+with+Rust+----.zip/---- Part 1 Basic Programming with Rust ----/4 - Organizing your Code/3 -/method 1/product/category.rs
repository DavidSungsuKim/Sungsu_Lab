pub enum Category {
    Electronics,
    Clothing,
    Books,
}
