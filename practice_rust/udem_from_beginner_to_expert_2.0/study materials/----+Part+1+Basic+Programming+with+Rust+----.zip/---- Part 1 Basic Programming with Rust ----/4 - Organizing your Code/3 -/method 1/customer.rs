pub struct Customer {
    id: u64, // this can be made private
    name: String,
    email: String, // this can be made private
}
